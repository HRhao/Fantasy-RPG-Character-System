package Assignment2;

public class Mage extends Character {
    private static final int MIN_SPELL_LEVEL = 5;

    private String elementalAffinity;

    // 添加参数校验
    public Mage(String id, String name, int level, String elementalAffinity) {
        super(id, name);

        if (level < 1) {
            throw new IllegalArgumentException("Level must be a positive integer.");
        }

        if (elementalAffinity == null || elementalAffinity.trim().isEmpty()) {
            throw new IllegalArgumentException("Elemental affinity cannot be null or empty.");
        }

        setLevel(level);
        this.elementalAffinity = elementalAffinity;
    }

    void castElementalSpell(String teleportation) {
        
    }

    // 枚举法术类型
    public enum SpellType {
        TELEPORTATION,
        ILLUSION,
        DETECTION
    }

    public void castElementalSpell(SpellType spellType) {
    if (getLevel() < MIN_SPELL_LEVEL) {
        System.out.println(getCharacterName() + " needs to reach level " + MIN_SPELL_LEVEL + " to cast spells.");
        return;
    }

    String message;
    switch (spellType) {
        case TELEPORTATION:
            message = "Teleporting " + getCharacterName() + " out of danger!";
            break;
        case ILLUSION:
            message = "Creating illusions to confuse the enemy.";
            break;
        case DETECTION:
            message = "Detecting the presence of magic nearby...";
            break;
        default:
            throw new IllegalArgumentException("Unknown spell type: " + spellType);
    }
    System.out.println(getCharacterName() + " is " + message);

    }

    @Override
    public void displayCharacterInfo() {
        super.displayCharacterInfo();
        System.out.println("Elemental Affinity: " + elementalAffinity);
    }

    @Override
    public String toString() {
        return super.toString() + ", Elemental Affinity: " + elementalAffinity;
    }
}

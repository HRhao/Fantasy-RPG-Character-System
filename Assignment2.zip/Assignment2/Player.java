package Assignment2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Define the Player class
class Player {
    private String playerID;
    private String playerName;
    private final List<Character> characters;

    public Player(String id, String name) {
        this.playerID = id;
        this.playerName = name;
        this.characters = new ArrayList<>();
    }

    public String getPlayerID() {
        return playerID;
    }

    public void setPlayerID(String playerID) {
        this.playerID = playerID;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public void addCharacter(Character character) {
        characters.add(character);
    }

    public List<Character> getCharacters() {
        return Collections.unmodifiableList(characters);
    }

    
}

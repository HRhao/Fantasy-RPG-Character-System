package Assignment2;

public class Rogue extends Character {
    private static final int DAMAGE_LEVEL_1 = 10;
    private static final int DAMAGE_LEVEL_2 = 15;
    private static final int DAMAGE_LEVEL_3 = 20;
    private static final int EVASION_THRESHOLD = 5;

    private int stealthLevel;
    private String daggerType;

    public Rogue(String id, String name, int level, int stealthLevel, String daggerType) {
        super(id, name);
        setLevel(level);
        this.stealthLevel = stealthLevel;
        this.daggerType = daggerType;
    }

    public void stab(Character target) {
        if (target == null) {
            System.out.println(getCharacterName() + " cannot stab a null target!");
            return;
        }

        int damage = calculateStabDamage();
        target.setHealth(target.getHealth() - damage);

        String message = String.format("%s stabs %s with %s for %d damage!", getCharacterName(), target.getCharacterName(), daggerType, damage);
        System.out.println(message);
    }

    private int calculateStabDamage() {
        if (getLevel() <= 3) {
            return DAMAGE_LEVEL_1;
        } else if (getLevel() <= 5) {
            return DAMAGE_LEVEL_2;
        } else {
            return DAMAGE_LEVEL_3;
        }
    }

    public void evade() {
        String message = (stealthLevel < EVASION_THRESHOLD)
                ? getCharacterName() + " needs a higher stealth level to evade attacks."
                : getCharacterName() + " successfully evades the incoming attack.";
        System.out.println(message);
    }

    @Override
    public void displayCharacterInfo() {
        super.displayCharacterInfo();
        System.out.println("Stealth Level: " + stealthLevel);
        System.out.println("Dagger Type: " + daggerType);
    }

    @Override
    public String toString() {
        return super.toString() + ", Stealth Level: " + stealthLevel + ", Dagger Type: " + daggerType;
    }
}

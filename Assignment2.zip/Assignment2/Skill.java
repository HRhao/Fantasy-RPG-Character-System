package Assignment2;

public class Skill {
    private final String skillName;
    private final String skillDescription;

    public Skill(String name, String description) {
        if (name == null || description == null) {
            throw new IllegalArgumentException("Skill name and description cannot be null.");
        }

        this.skillName = name;
        this.skillDescription = description;
    }

    public String getSkillName() {
        return skillName;
    }

    public String getSkillDescription() {
        return skillDescription;
    }

    @Override
    public String toString() {
        if (skillName == null || skillDescription == null) {
            return "Invalid Skill"; // or throw an exception, depending on your preference
        }
        return skillName + ": " + skillDescription;
    }
}

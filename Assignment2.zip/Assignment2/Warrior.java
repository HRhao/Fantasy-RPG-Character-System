package Assignment2;

public class Warrior extends Character {
    private static final int SWORD_DAMAGE_LEVEL_1 = 25;
    private static final int SWORD_DAMAGE_LEVEL_2 = 50;
    private static final int DAGGER_DAMAGE = 20;
    private static final int CROSSBOW_DAMAGE = 50;
    private static final int STAFF_DAMAGE = 10;

    private static final String DEFAULT_MESSAGE = "I hope you're protected... somehow.";

    private String weaponType;
    private String armorType;

    public Warrior(String id, String name, int level, String weaponType, String armorType) {
        super(id, name);
        setLevel(level);
        this.weaponType = weaponType;
        this.armorType = armorType;
    }

    public void chargeAttack(Character target) {
        if (target == null) {
            System.out.println(getCharacterName() + " cannot charge attack a null target!");
            return;
        }

        int damage = calculateChargeAttackDamage();
        target.setHealth(target.getHealth() - damage);

        String message = String.format("%s attacks %s with %s for %d damage!", getCharacterName(), target.getCharacterName(), weaponType, damage);
        System.out.println(message);
    }

    private int calculateChargeAttackDamage() {
        switch (weaponType) {
            case "Sword":
                return getLevel() > 5 ? SWORD_DAMAGE_LEVEL_2 : SWORD_DAMAGE_LEVEL_1;
            case "Dagger":
                return DAGGER_DAMAGE;
            case "Crossbow":
                return CROSSBOW_DAMAGE;
            case "Staff":
                return STAFF_DAMAGE;
            default:
                return 0;
        }
    }

    public void shieldBlock() {
        String message;
        switch (armorType) {
            case "Shield":
                message = getCharacterName() + " is raising its shield.";
                break;
            case "Gauntlet":
                message = getCharacterName() + " is raising its gauntlets.";
                break;
            case "Helmet":
                message = getCharacterName() + "'s head is protected.";
                break;
            default:
                message = DEFAULT_MESSAGE;
                break;
        }
        System.out.println(message);
    }

    @Override
    public void displayCharacterInfo() {
        super.displayCharacterInfo();
        System.out.println("Weapon Type: " + weaponType);
        System.out.println("Armor Type: " + armorType);
    }

    @Override
    public String toString() {
        return super.toString() + ", Weapon Type: " + weaponType + ", Armor Type: " + armorType;
    }
}
